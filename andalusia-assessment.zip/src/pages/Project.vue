<template>
  <!-- <div class="project">
    <div class="project-holder">
      <div class="content">
        <h2>image project</h2>
        <ul class="content-items">
          <li>
            <q-icon name="arrow_right_alt" />titke
            <span class="title"></span>
            <span class="item"></span>
          </li>
        </ul>
      </div>
    </div>
  </div> -->
  jlhko
</template>

<script>

export default {
    props:["id"],
    setup(props){
        console.log(props);


        return{

        }
    }

}
</script>

<style>
</style>